var people = new Array( 0 );

function switchTab( i ) {
  window.location.href = "javascript:document.querySelector('#app').selected = Number(" + i + ")";
}